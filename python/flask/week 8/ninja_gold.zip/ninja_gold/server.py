from flask import Flask, request, render_template, redirect, session
app = Flask(__name__)
app.secret_key = 'Brooklyn'
from datetime import datetime
import random

@app.route('/')
def index():
    if 'points_earned' not in session:
        session['points_earned'] = 0

    if 'location' not in session:
        session['location'] = []

    location = session['location']

# make the list appear in reverse order in HTML
    flip_list = []

    for x in range(len(location)-1,-1,-1):
            flip_list.append(location[x])
# render location as a variable for Jinja to HTML
    return render_template('index.html',location=location)

@app.route('/process', methods=['POST'])
def process():
    hidden_input = request.form['hidden_input']
    session['points_earned'] = 0

    if 'location' not in session:
        session['location'] = []

    location=session['location']

    if hidden_input == 'farm':
        random_number = random.randint(10,20)
        location.append({'hidden_input_name': 'farm','points_earned':random_number,'date': datetime.now()}),
        session['points_earned'] += random_number

    elif hidden_input == 'cave':
        random_number = random.randint(5,10)
        location.append({'hidden_input_name': 'cave', 'points_earned':random_number, 'date': datetime.now()})
        session['points_earned'] += random_number
    elif hidden_input == 'house':
        random_number = random.randint(2,5)
        location.append({'hidden_input_name': 'house', 'points_earned':random_number, 'date': datetime.now()})
        session['points_earned'] += random_number
    else:
        hidden_input == 'casino'
        random_number = random.randint(-50,50)
        location.append({'hidden_input_name': 'casino', 'points_earned':random_number, 'date': datetime.now()},)
        session['points_earned'] += random_number
    # print(f'you pressed {hidden_input}')
    # print(location)
    return redirect('/')

@app.route('/reset' ,methods = ['POST'])
def reset():
    session.clear()

    return redirect('/')

if __name__=='__main__':
    app.run(debug=True)