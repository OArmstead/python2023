from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def html_table():

    users = [ {'first_name': 'James','last_name':'Bond'},
            {'first_name': 'Larry','last_name':'Bird'},
            {'first_name': 'James','last_name': 'Brown'}

    ]
    return render_template('index.html', users = users, count = count)


if __name__=='__main__':
    app.run(debug=True)
