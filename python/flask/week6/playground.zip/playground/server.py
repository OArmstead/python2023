from flask import Flask, request, render_template, redirect, session
app = Flask(__name__)

@app.route('/')
def index():
    return 'Enter the number of boxes and their color in the browser. After localhost: 5000 Thank you!'

# The number of boxes and their color has to be passed through
@app.route('/<int:num>/<color>')
def play_color(num,color):
# num & color are parameters that has to be converted
# to variables to get rendered in HTML for Jinja
    num = num
    color = color
    return render_template('index.html', num = num, color = color)



if __name__=='__main__':
    app.run(debug=True)