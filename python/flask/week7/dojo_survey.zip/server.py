

from flask import Flask, render_template,request,redirect,session
app = Flask(__name__)
app.secret_key= 'Maverick'

@app.route('/')

def you_got_this():
    print('You had it in you all along')
    
    
    if 'jam'  in session:
        print('Key in session')
    else:
        print('key not in session')
    # return redirect('/process')
    return render_template('index.html')

@app.route('/process', methods=['POST'])

def process():
    session['name']=request.form['name']
    session['location']=request.form['location']
    session['lang']=request.form['lang']
    session['comment']=request.form['comment']
    return redirect('/result')

@app.route('/result')

def result():
    return render_template('result.html')

@app.route('/reset')
def reset():
    session.clear()
    return redirect('/')






if __name__=="__main__":  
    app.run(debug=True)