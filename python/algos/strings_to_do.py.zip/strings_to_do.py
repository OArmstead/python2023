


# Create a function that, given a string,
# returns all of that string’s contents, but without blanks.

# If given the string " Pl ayTha tF u nkyM usi c ", return "PlayThatFunkyMusic".

def remove_blanks(string):
    new_list = " "
    for x in string:
        if x != " ":
#toss the blank spaces in the empty string
            new_list += x
    return new_list
print(remove_blanks(" Pl ayTha tF u nkyM usi c "))

'''
Create a Python function that given a string,
returns the integer made from the string's digits.
Given "os1a3y5w7h9a2t4?6!8?0",
the function should return the number 1357924680.
'''
def get_digits(string):
    filtered_string = ''
    digits = '0123456789'
    for x in string:
        if x in digits:
            filtered_string += x
    # print(trash)
    return filtered_string
results = get_digits('os1a3y5w7h9a2t4?6!8?0')
print(results)



'''
Create a function that, given a string, returns the string’s acronym (first letters only, capitalized).
Given " there's no free lunch - gotta pay yer way. ", return "TNFL-GPYW".
Given "Live from New York, it's Saturday Night!", return "LFNYISN".

'''

def first_letters(string):
    new_string = ""
    start_of_words = True
    for x in string:
        if x != " ":
#start of words already = True no need to add it in condition.
            if start_of_words:
                new_string += x
            start_of_words = False
        else:
            start_of_words = True
    return new_string.upper()

results = first_letters("Live from New York, it's Saturday Night!")
print(results)

'''

Dictionaries are sometimes called maps because a key
(string) maps to a value. Given two arrays,
create an associative array (map)
containing keys of the first, and values of the second.
For arr1 = ["abc", 3, "yo"] and arr2 = [42, "wassup", true],
return {"abc": 42, 3: "wassup", "yo": true}.
'''

def mapping(arr1,arr2):

    new_dict = {}
    for i in range(len(arr1)):
        key = arr1[i]
        if i < len(arr2):
            value = arr2[i]
        else: value = None
        new_dict[key] = value
    return new_dict

arr1 = ["abc", 3, "yo"]
arr2 = [42, "wassup", True]
results = mapping(arr1,arr2)
print(results)


'''
Dictionaries are also called hashes (we’ll learn why later).
Build invertHash(assocArr) to convert hash keys to values, and values to keys.

Example: given {"name": "Zaphod", "charm": "high", "morals": "dicey"},

return object {"Zaphod": "name", "high":"charm", "dicey": "morals"}.
'''

def switch_dict(info):
    new_dict = {}
    for x,y in  info.items():
        new_dict[y] = x
    return new_dict
results = switch_dict({"Zaphod": "name", "high":"charm", "dicey": "morals"})
print (results)

