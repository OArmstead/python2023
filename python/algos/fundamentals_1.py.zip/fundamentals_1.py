# 1. Multiples of Three – but Not All

# Using FOR, print multiples of 3 from -300 to 0. Skip -3 and -6.


def multiples_of_three():
    for num in range(-300,1):
        # print(num)
        if num % 3 == 0 and num != -3 and num != -6:
            # if num == -3:
            #     continue
            # if num == -6:
            #     continue
            print(num)

multiples_of_three()



# 2. Printing Integers with While

# Print integers from 2000 to 5280, using a WHILE.

def printing_with_while():
    x = 2000
    while x < 5281:
        print(x)
        x += 1
printing_with_while()


# 3. Counting, the Dojo Way

# Print integers 1 to 100. If divisible by 5, print "Coding" instead. If by 10, also print " Dojo".

def dojo_counting():
    for x in range(1,101):
        # print(x)
        if x % 10 == 0:
            print(x,'Dojo')
        elif x % 5 == 0:
            print(x, 'Coding')
        else: print(x)
dojo_counting()

# 4. Flexible Countdown

# Given lowNum, highNum, mult, print multiples of mult from highNum down to lowNum, using a FOR. For (2,9,3), print 9 6 3 (on successive lines).

def countdown(lowNum,highNum,multi):
    for x in range(highNum,lowNum, -1):
        if x % multi == 0:
            print(x)


countdown(2,9,3)

