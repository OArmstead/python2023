# On instantiation of a user, the following
# attributes should be passed in as arguments:

# first_name
# last_name
# email
# age
class User:

    def __init__(self,first_name,last_name,email,age) :
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.age =age
        self.is_rewards_member = False
        self.gold_card_points = 0


#display_info(self) - Have this method print
# all of the users' details on separate lines.

    def display_info(self):
        print()
        print(f'{self.first_name} {self.last_name} | email: {self.email} | age {self.age}')
        print()

# enroll(self) - Have this method change the user's member
# status to True and set their gold card points to 200.

    def enroll(self):
# Add logic in the enroll method to check if they are a member already,
# and if they are, print "User already a member." and return False,
# otherwise return True.
        if self.is_rewards_member:
            print('User Already Member')
            return False

        self.is_rewards_member = True
        self.gold_card_points = 200
        print()
        print(f'{self.first_name} {self.last_name} is a member? {self.is_rewards_member} ')
        print()
        print(f'Your Gold Card Points balance: {self.gold_card_points}')
        return self.is_rewards_member

# spend_points(self, amount) have this method
# decrease the user's points by the amount specified.
    def spend_points(self,amount):
# Add logic in the spend points method to be
# sure they have enough points to spend that
# amount and handle appropriately.
        new_amount = self.gold_card_points - amount
        print()
        print(f"{self.first_name} {self.last_name} spent {amount} Gold Card Points.")
        print(f'Current Balance: {new_amount}')
# BONUS: Implement the logic to prevent over-spending
        if new_amount < 0:
            print(f"You're spending {amount} over balance")
            print('Insufficient Funds')
        print()
        print()


user1 = User('James','Bond','007@gmail.com','41')
user2 = User('Sam','Cook','S.Cook@gmal.com','60')
user3 = User('Peter','Parker','TheRealSpiderman@marvel.com','22')


#display_info(self) - Have this method print all of the
# users' details on separate lines.

user1.display_info()
user2.display_info()
user3.display_info()


# Have the first user spend 50 points
user1.display_info(),user1.enroll(),user1.spend_points(50)
# BONUS: Implement the logic for testing
# if already a member and try to re-enroll the first user.
user1.enroll()

# Have the second user enroll.
# Have the second user spend 80 points
# user2.enroll(),user2.spend_points(80)


# # Call the display method on all the users.
user1.display_info(),user2.display_info(),user3.display_info(),


# call the spend_points method with 40 points on the 3rd user.
user3.spend_points(40)
