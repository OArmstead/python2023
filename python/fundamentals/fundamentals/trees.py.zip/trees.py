

'''''

BST: Add

Create an add(val) method on the BST object to add new value to the tree.
This entails creating a BTNode with this value and connecting it at the appropriate place in the tree.
Unless specified otherwise, BSTs can contain duplicate values.




BST: Contains

Create a contains(val) method on BST that
returns whether the tree contains a given value.
Take advantage of the BST structure to make
this a much more rapid operation than SList.contains() would be.



BST: Min

Create a min() method on the BST class that
returns the smallest value found in the BST.



BST: Max

Create a max() BST method that returns
the largest value contained in the binary search tree.

'''''



class TreeNode:
    def __init__(self, value):
        self.val = value
        self.left = None
        self.right = None

class BinarySearchTree:
    def __init__(self):
        self.root = None
        self.values_added = []

    def add(self, value):
        new_node = TreeNode(value)
        if self.root is None:
            self.root = new_node
        else:
            self._add_recursive(self.root, new_node)
        self.values_added.append(value)

    def _add_recursive(self, current_node, new_node):
        if new_node.val < current_node.val:
            if current_node.left is None:
                current_node.left = new_node
            else:
                self._add_recursive(current_node.left, new_node)
        else:
            if current_node.right is None:
                current_node.right = new_node
            else:
                self._add_recursive(current_node.right, new_node)

    def print_tree(self):
        def inorder_traversal(node):
            stack = []
            current = node

            while stack or current:
                if current:
                    stack.append(current)
                    current = current.left
                else:
                    current = stack.pop()
                    print(current.val)
                    current = current.right

        print("Tree Structure:")
        inorder_traversal(self.root)

    def contains(self, value):
        current = self.root
        while current:
            if value == current.val:
                return True
            elif value < current.val:
                current = current.left
            else:
                current = current.right
        return False

    def min(self):
        current = self.root
        while current.left:
            current = current.left
        return current.val

    def max(self):
        current = self.root
        while current.right:
            current = current.right
        return current.val

bst = BinarySearchTree()
bst.add(10)
bst.add(5)
bst.add(15)
bst.add(3)
bst.add(7)

# Print the tree structure
bst.print_tree()

print("Values Added:", bst.values_added)
print("Minimum Value:", bst.min())
print("Maximum Value:", bst.max())

