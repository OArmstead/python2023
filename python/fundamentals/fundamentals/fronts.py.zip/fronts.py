


class Node:
    def __init__(self,val):
        self.val = val
        self.next = None
# class instance
first_node = Node(11)
print(first_node.val)
# created_second_node
first_node.next = Node("I'm node #2")
print(first_node.next.val)

# list
class SLL:
    def __init__(self):
        self.head = None

    def add_to_back(self, val):
        new_node = Node(val)
        if self.head == None:
            self.head = new_node
            return self
first_sll = SLL()
first_sll.add_to_back(21)
print(first_sll.head.val)
# make first_node head of list


class LinkedList:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def add_node(self, data):
        new_node = {"data": data, "next": self.head}
        self.head = new_node

    def remove_head(self):
        if self.is_empty():
            return None
        removed_data = self.head["data"]
        self.head = self.head["next"]
        return removed_data


my_list = LinkedList()


my_list.add_node(10)
my_list.add_node(20)
my_list.add_node(30)

# Remove the head node
removed_data = my_list.remove_head()

if removed_data is not None:
    print("Removed data:", removed_data)
else:
    print("The list is empty.")

# Check if the list is empty
if my_list.is_empty():
    print("The list is now empty.")
else:
    print("The list is not empty.")


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class list:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def add_front(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node
        return self.head


my_list = list()


my_list.add_front(10)
my_list.add_front(20)
my_list.add_front(30)


current_node = my_list.head
while current_node:
    print(current_node.data)
    current_node = current_node.next
