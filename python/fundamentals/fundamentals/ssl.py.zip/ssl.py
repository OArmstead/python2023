


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def add_front(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

    def contains(self, value):
        current = self.head
        while current:
            if current.data == value:
                return True
            current = current.next
        return False


list = List()

# Add elements to the list
list.add_front(10)
list.add_front(20)
list.add_front(30)


if list.contains(20):
    print("The list contains 20")
else:
    print("The list does not contain 20")

if list.contains(40):
    print("The list contains 40")
else:
    print("The list does not contain 40")



class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class List:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def add_front(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

    def contains(self, value):
        current = self.head
        while current:
            if current.data == value:
                return True
            current = current.next
        return False

    def length(self):
        count = 0
        current = self.head
        while current:
            count += 1
            current = current.next
        return count


alist = SinglyLinkedList()

# Add elements to the list
alist.add_front(10)
alist.add_front(20)
alist.add_front(30)

# Get the length of the list
length = alist.length()
print("Length of the list:", length)


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def add_front(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node

    def display(self):
        current = self.head
        values = []
        while current:
            values.append(current.data)
            current = current.next
        return " -> ".join(map(str, values))

# Example usage:
my_list = SinglyLinkedList()

# Add elements to the list
my_list.add_front(10)
my_list.add_front(20)
my_list.add_front(30)

# Display the list as a string
list_str = my_list.display()
print("List:", list_str)
