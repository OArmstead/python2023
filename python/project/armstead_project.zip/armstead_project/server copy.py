from charles_arnolds import app
#    <----------------add controllers here --------->
from charles_arnolds.controllers import reviews_controller
from charles_arnolds.controllers import users_controller
from charles_arnolds.controllers import cheesecake_controller
from charles_arnolds.controllers import orders_controller

if __name__=='__main__':
    app.run(debug=True)



