from flask import Flask, request, render_template, redirect, session
from flask_bootstrap import Bootstrap
app = Flask(__name__)
Bootstrap(app)
app.secret_key ='Brooklyn'






