function changeBackgroundImage(imageUrl) {
    console.log('Function called with image URL:', imageUrl);
    document.getElementById("second_page").style.backgroundImage = `url('${imageUrl}')`;
}




document.addEventListener('DOMContentLoaded', function () {
    const ratingInput = document.getElementById('rating');
    const ratingLabels = document.querySelectorAll('.rating-labels .label');
    const minValue = document.querySelector('.min-value');
    const maxValue = document.querySelector('.max-value');
    const cakeSelect = document.getElementById('cakeSelect');
    const cakeIdInput = document.getElementById('cakeId');

    ratingInput.addEventListener('input', () => {
        const value = parseFloat(ratingInput.value);

        if (value === 0) {
            ratingLabels[0].style.visibility = 'visible';
            ratingLabels[1].style.visibility = 'hidden';
            ratingLabels[2].style.visibility = 'hidden';
        } else if (value === 2.5) {
            ratingLabels[0].style.visibility = 'hidden';
            ratingLabels[1].style.visibility = 'visible';
            ratingLabels[2].style.visibility = 'hidden';
        } else if (value === 5) {
            ratingLabels[0].style.visibility = 'hidden';
            ratingLabels[1].style.visibility = 'hidden';
            ratingLabels[2].style.visibility = 'visible';
        } else {
            ratingLabels[0].style.visibility = 'hidden';
            ratingLabels[1].style.visibility = 'hidden';
            ratingLabels[2].style.visibility = 'hidden';
        }

        // Update numeric range values
        minValue.textContent = value;
        maxValue.textContent = (5 - value).toFixed(1);
    });

    // Update cake ID when the user selects a different cake
    cakeSelect.addEventListener('change', () => {
        cakeIdInput.value = cakeSelect.value;
    });
});



// Add event listeners to update the summary whenever there's a change in selection
document.querySelector('select[name="cheesecake_id"]').addEventListener('change', updateSummary);
document.querySelector('select[name="quantity"]').addEventListener('change', updateSummary);

// Function to update the summary based on the selected options
function updateSummary() {
    var cheesecakePrice = parseFloat(document.querySelector('select[name="cheesecake_id"]').value);
    var quantity = parseInt(document.querySelector('select[name="quantity"]').value);
    var subtotal = cheesecakePrice * quantity;
    var total = subtotal; // Add additional costs here if needed

    // Update the HTML elements with the calculated values
    document.getElementById('subtotal-amount').textContent = '$' + subtotal.toFixed(2);
    // Update other relevant HTML elements
}

// Initial update of the summary when the page loads
updateSummary();
