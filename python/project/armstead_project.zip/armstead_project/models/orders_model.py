# models/order_model.py

from charles_arnolds.config.mysqlconnection import connectToMySQL
from charles_arnolds.models.user_model import User
from charles_arnolds.models.cheesecake_model import Cheesecake

db = 'charles_arnolds'

class Order:
    def __init__(self, data):
        self.order_id = data['order_id']
        self.user_id = data['user_id']
        self.cheesecake_id = data['cheesecake_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.quantity = data['quantity']  # Added quantity field
        self.total = data['total']  # Added total field




    @classmethod
    def create_order(cls, user_id, cheesecake_id, quantity, total):
        query = """
            INSERT INTO orders (user_id, cheesecake_id, quantity, total)
            VALUES (%(user_id)s, %(cheesecake_id)s, %(quantity)s, %(total)s);
        """
        data = {
            'user_id': user_id,
            'cheesecake_id': cheesecake_id,
            'quantity': quantity,
            'total': total
        }
        order_id = connectToMySQL(db).query_db(query, data)
        return order_id

    @classmethod
    def get_orders_by_user_id(cls, user_id):
        query = "SELECT * FROM orders WHERE user_id = %(user_id)s;"
        data = {'user_id': user_id}
        results = connectToMySQL(db).query_db(query, data)
        orders = []
        for row in results:
            orders.append(cls(row))
        return orders

    # You can add more methods as needed for order-related operations


    # @staticmethod
    # def get_cheesecake_price(selected_size):
    #     # Query the database to get the pricing_id based on the selected size
    #     query = "SELECT pricing_id, price FROM cake_pricing WHERE size = %(size)s;"
    #     data = {'size': selected_size}

    #     result = connectToMySQL(db).query_db(query, data)

    #     if result:
    #         pricing_id = result[0]['pricing_id']
    #         cheesecake_price = result[0]['price']
    #         return cheesecake_price

    #     # Handle invalid size or size not found in the database
    #     raise ValueError("Invalid cheesecake size or size not found in the database")



    @staticmethod
    def get_cheesecake_price(selected_size):
    # Query the database to get the pricing_id based on the selected size
        query = "SELECT pricing_id, price FROM cake_pricing WHERE size = %(size)s;"
        data = {'size': selected_size}

        result = connectToMySQL(db).query_db(query, data)

        if result:
            pricing_id = result[0]['pricing_id']
            cheesecake_price = result[0]['price']
            return cheesecake_price

        # If no result found, return None instead of raising an error
        return None








    @staticmethod
    def calculate_subtotal_and_total(cheesecake_price, quantity):
        # Calculate subtotal and total based on cheesecake price and quantity
        subtotal = cheesecake_price * quantity
        total = subtotal  # You can add additional costs here if needed
        return subtotal, total



    @classmethod
    def create_order_in_database(cls, order_data):
        query = """
            INSERT INTO orders (user_id, cheesecake_id, quantity, total)
            VALUES (%(user_id)s, %(cheesecake_id)s, %(quantity)s, %(total)s);
        """
        order_id = connectToMySQL(db).query_db(query, order_data)
        return order_id



    @classmethod
    def get_cheesecake_quantity(cls, cheesecake_id, selected_size):
        query = """
        SELECT SUM(orders.quantity) as total_quantity
        FROM orders
        JOIN cheesecakes ON orders.cheesecake_id = cheesecakes.cheesecake_id
        WHERE cheesecakes.cheesecake_id = %(cheesecake_id)s
        AND cheesecakes.size = %(selected_size)s;
        """
        data = {
            'cheesecake_id': cheesecake_id,
            'selected_size': selected_size
        }

        # Debugging: Print the query and data to check if they are correct
        print("Running Query:", query)
        print("Query Data:", data)

        result = connectToMySQL(db).query_db(query, data)

        if result:
            # Debugging: Print the result to see what's retrieved from the database
            print("Query Result:", result)

            # Check if the result is NULL and return 0 if it is
            if result[0]['total_quantity'] is None:
                return 0
            else:
                return result[0]['total_quantity']
        else:
            return 0  # Return 0 if no records found


# Testing code outside the class definition
if __name__ == "__main__":
    cheesecake_id = 1  # Replace with an actual cheesecake_id
    selected_size = '8in'  # Replace with an actual selected_size

    result = Order.get_cheesecake_quantity(cheesecake_id, selected_size)
    print("Result:", result)

