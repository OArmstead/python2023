from charles_arnolds.config.mysqlconnection import connectToMySQL
from flask import flash
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
from flask_bcrypt import Bcrypt
import pprint
import pymysql.cursors


db = 'charles_arnolds'

class Cheesecake:
    def __init__(self, data):
        self.id = data['cheesecake_id']
        self.name = data['name']
        self.filling = data['filling']
        self.topping = data['topping']
        self.crust = data['crust']
        self.size = data['size']
        self.pricing_id = data['pricing_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    # ... (other existing methods) ...

    @classmethod
    def get_reviews_for_cheesecake(cls, cheesecake_id):
        query = """
        SELECT reviews.rating, reviews.comment, users.first_name, users.last_name
        FROM reviews
        JOIN users ON reviews.user_id = users.id
        WHERE reviews.cheesecake_id = %(cheesecake_id)s;
        """
        data = {'cheesecake_id': cheesecake_id}
        results = connectToMySQL(db).query_db(query, data)
        reviews = []
        for row in results:
            reviewer_name = f"{row['first_name']} {row['last_name']}"
            reviews.append({
                'rating': row['rating'],
                'comment': row['comment'],
                'reviewer_name': reviewer_name
            })
        return reviews

    # Method to get cheesecake price
    @classmethod
    def get_cheesecake_price(cls, cheesecake_id, selected_size=None):
        if selected_size is None:
            # Set a default size or handle it as needed
            selected_size = "8in"  # You can change this to the desired default size

        query = "SELECT price FROM cake_pricing WHERE cheesecake_id = %(cheesecake_id)s AND size = %(size)s;"
        data = {'cheesecake_id': cheesecake_id, 'size': selected_size}
        print(f"Selected Size: {selected_size}")
        print(f"Cheesecake ID: {cheesecake_id}")

        result = connectToMySQL(db).query_db(query, data)
        print(f"Running Query: {query}")
        print(f"Query Data: {data}")

        if result:
            price = result[0]['price']
            print(f"Price Found: {price}")
            return price
        else:
            flash(f"Pricing for Size {selected_size} not found in the database", 'error')
            print(f"Pricing for Size {selected_size} not found in the database")
            raise ValueError(f"Pricing for Size {selected_size} not found in the database")



    # Method to get cheesecake size by ID
    @classmethod
    def get_cheesecake_size(cls, cheesecake_id):
        query = "SELECT size FROM cheesecakes WHERE cheesecake_id = %(cheesecake_id)s;"
        data = {'cheesecake_id': cheesecake_id}
        result = connectToMySQL(db).query_db(query, data)

        if result:
            cheesecake_size = result[0]['size']
            return cheesecake_size
        else:
            flash(f"Cheesecake Size for ID {cheesecake_id} not found in the database", 'error')
            raise ValueError(f"Cheesecake Size for ID {cheesecake_id} not found in the database")



    @staticmethod
    def is_valid_cheesecake_size(cheesecake_id, selected_size):
        try:
            # Query the database to check if the given cheesecake_id and selected_size combination exists
            query = "SELECT COUNT(*) FROM cheesecakes WHERE cheesecake_id = %(cheesecake_id)s AND size = %(selected_size)s;"
            data = {
                'cheesecake_id': cheesecake_id,
                'selected_size': selected_size
            }

            # Execute the query using your database library
            result = connectToMySQL(db).query_db(query, data)

            # Debugging print statements
            print(f"Running Query: {query}")
            print(f"Query Data: {data}")

            # If the result is greater than 0, it means a matching cheesecake with the selected size exists
            if result and result[0]['COUNT(*)'] > 0:
                print(f"Cheesecake with ID {cheesecake_id} and size {selected_size} exists.")
                return True
            else:
                print(f"No matching cheesecake found with ID {cheesecake_id} and size {selected_size}.")
                return False

        except Exception as e:
            # Handle any database errors here
            print("An error occurred while checking cheesecake size:", str(e))
            return False  # Return False in case of an error









   # ...

# In your Cheesecake model class
    # ...

# In your Cheesecake model class
    @classmethod
    def get_cheesecake_name(cls, cheesecake_id):
        query = "SELECT name FROM cheesecakes WHERE cheesecake_id = %(cheesecake_id)s;"
        data = {'cheesecake_id': cheesecake_id}

        try:
            connection = connectToMySQL(db)
            cursor = connection.cursor(pymysql.cursors.DictCursor)  # Explicitly create a cursor

            cursor.execute(query, data)
            result = cursor.fetchone()  # Fetch the result

            cursor.close()
            connection.close()

            if result:
                return result['name']  # Return the cheesecake name
            else:
                return "Cheesecake Not Found"  # Handle the case where no result is found
        except Exception as e:
            print("An error occurred while fetching cheesecake name:", str(e))
            return None
