from charles_arnolds.config.mysqlconnection import connectToMySQL
from flask import flash

import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
import pprint

db = 'charles_arnolds'

class Review:
    def __init__(self, data):
        self.review_id = data['review_id']
        self.user_id = data['user_id']
        self.cheesecake_id = data['cheesecake_id']
        self.rating = data['rating']
        self.comment = data['comment']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']






    @classmethod
    def save_review(cls, data):
        # Define the SQL query to insert the review data
        query = """
        INSERT INTO reviews (cheesecake_id, user_id, rating, comment)
        VALUES (%(cheesecake_id)s, %(user_id)s, %(rating)s, %(comment)s)
        """

        # Assuming connectToMySQL(db) connects to your database
        results = connectToMySQL(db).query_db(query, data)

        return results




    @classmethod
    def get_all_users_reviews(cls):
        query = """
        SELECT reviews.rating, reviews.comment, users.first_name, users.last_name, cheesecakes.name AS cheesecake_name
        FROM reviews
        JOIN users ON reviews.user_id = users.id
        JOIN cheesecakes ON reviews.cheesecake_id = cheesecakes.cheesecake_id
        """

        # Use your custom database connection to execute the query
        db_connection = connectToMySQL(db)
        results = db_connection.query_db(query)

        reviews = []
        for row in results:
            # reviewer_name = f"{row['first_name']} {row['last_name']}"
            reviews.append({
                'rating': row['rating'],
                'comment': row['comment'],
                'first_name': row['first_name'],
                'last_name': row['last_name'],
                # 'reviewer_name': reviewer_name,
                'cheesecake_name': row['cheesecake_name']
            })

        return reviews




    @classmethod
    def get_one(cls, review_id):
        query = "SELECT * FROM reviews WHERE review_id = %(review_id)s;"
        data = {'review_id': review_id}
        results = connectToMySQL(db).query_db(query, data)
        return cls(results[0])

    # Add other methods for update, delete, and retrieval as needed

    @staticmethod
    def validate_review(review_data):
        # Implement validation logic for review data
        is_valid = True

        # Example validation checks
        try:
            rating = float(review_data['rating'])
            if rating < 1 or rating > 5:
                flash('Invalid rating! Please choose a rating between 1 and 5.', 'error')
                is_valid = False
        except ValueError:
            flash('Invalid rating format! Please enter a valid numeric rating between 1 and 5.', 'error')
            is_valid = False

        if len(review_data['comment']) < 5:
            flash('Comment must be at least 5 characters.', 'error')
            is_valid = False

        return is_valid


    @classmethod
    def create_review(cls, cheesecake_id, user_id, rating, comment):
        # Perform server-side validation
        if not cheesecake_id or not user_id or not rating:
            return None  # Return None to indicate validation failure

        try:
            cheesecake_id = int(cheesecake_id)
            user_id = int(user_id)
            rating = float(rating)
        except ValueError:
            return None  # Return None to indicate validation failure

        query = """
        INSERT INTO reviews (cheesecake_id, user_id, rating, comment)
        VALUES (%(cheesecake_id)s, %(user_id)s, %(rating)s, %(comment)s);
        """
        data = {
            'cheesecake_id': cheesecake_id,
            'user_id': user_id,
            'rating': rating,
            'comment': comment
        }

        db_connection = connectToMySQL(db)

        try:
            with db_connection.connection.cursor() as cursor:
                cursor.execute(query, data)
                db_connection.connection.commit()
                review_id = cursor.lastrowid
                print("Review inserted successfully. Review ID:", review_id)
                return review_id
        except Exception as e:
            print("Error inserting review into the database:", str(e))
            return None
        finally:
            db_connection.connection.close()
