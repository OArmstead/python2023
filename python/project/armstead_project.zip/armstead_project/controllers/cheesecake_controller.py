from charles_arnolds.config.mysqlconnection import connectToMySQL
from flask import Flask, request, render_template, redirect, session,flash,get_flashed_messages
from charles_arnolds import app
from charles_arnolds.models.cheesecake_model import Cheesecake
from flask_bcrypt import Bcrypt
import pprint
bcrypy = Bcrypt(app)



@app.route('/rating')
def review():
    messages = get_flashed_messages()
    cheesecakes = Cheesecake.get_all_cheesecakes()  # Fetch cheesecakes using your model method
    user_id = session.get('user_id')  # Retrieve user_id from the session
    return render_template('rating.html', cheesecakes=cheesecakes, user_id=user_id,messages=messages)


# @app.route('/checkout')
# def checkout():
#     quantity_range = range(0,11)
#     item = "Cheesecake"
#     total = 25.00
#     quantity =2

#     return render_template('checkout.html', item = item, total=total, quantity = quantity, quantity_range = quantity_range)


# @app.route('/thankyou')
# def thankyou():
#     quantity = range(0,11)
#     item = "Cheesecake"
#     total = 25.00
#     quantity =2

#     return render_template('thankyou.html', item = item, total=total, quantity = quantity)



@app.route('/test_db', methods=['GET'])
def test_db():
    try:
        query = "SELECT name FROM cheesecakes WHERE cheesecake_id = %(cheesecake_id)s;"
        cheesecake_id = 2  # Change this to the ID of the cheesecake you want to retrieve the name for
        data = {'cheesecake_id': cheesecake_id}

        result = connectToMySQL('charles_arnolds').query_db(query, data)
        
        if result:
            cheesecake_name = result[0]['name']
            return f"Cheesecake Name: {cheesecake_name}"
        else:
            return "Cheesecake Not Found"
    except Exception as e:
        print("Database query error:", e)
        return "Database query error"

