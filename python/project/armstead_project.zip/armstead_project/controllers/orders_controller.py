from flask import Flask, request, render_template, redirect, session, flash, url_for
from charles_arnolds import app
from charles_arnolds.models.cheesecake_model import Cheesecake
from charles_arnolds.models.orders_model import Order
from flask_bcrypt import Bcrypt
import pprint

bcrypt = Bcrypt(app)


# @app.route('/checkout_error')
# def checkout_error():
#     # Handle the error here, e.g., display an error message to the user
#     return "Checkout Error: Invalid input data."



@app.route('/checkout', methods=['GET'])
def display_checkout():
    # Retrieve the parameters from the request (assuming they come from a form or URL query string)
    selected_size = request.args.get('size')  # Assuming 'size' is a parameter for cheesecake selection
    cheesecake_id = request.args.get('id')    # Assuming 'id' is the cheesecake's unique identifier

    # Debugging print statements
    print(f"selected_size: {selected_size}")
    print(f"cheesecake_id: {cheesecake_id}")

    # Ensure that cheesecake_id and selected_size are not None and have valid values
    # if not selected_size or not cheesecake_id:
    #     flash("Invalid input data. Please select a cheesecake and size.", "error")
    #     return redirect(url_for('checkout_error'))  # Replace 'checkout_error' with the actual error page

    # Validate that cheesecake_id and selected_size exist in the database (you may need to implement these checks)
    # if not Cheesecake.exists(cheesecake_id):  # Provide the correct db_name
    #     flash("Invalid cheesecake selection.", "error")
    #     return redirect(url_for('checkout_error'))  # Replace 'checkout_error' with the actual error page

    # if not Cheesecake.is_valid_size(cheesecake_id, selected_size):
    #     flash("Invalid size selection.", "error")
    #     return redirect(url_for('checkout_error'))  # Replace 'checkout_error' with the actual error page

    # Retrieve the cheesecake price and quantity here
    cheesecake_price = Cheesecake.get_cheesecake_price(cheesecake_id, selected_size)
    quantity = Order.get_cheesecake_quantity(cheesecake_id, selected_size)

    # Debugging print statements
    print(f"cheesecake_price: {cheesecake_price}")
    print(f"quantity: {quantity}")

    # Calculate subtotal and total (assuming shipping is free)
    subtotal = cheesecake_price * quantity
    shipping = 0  # Assuming shipping is free
    total = subtotal + shipping

    # Debugging print statements
    print(f"subtotal: {subtotal}")
    print(f"total: {total}")

    # Render the checkout page and pass the price, quantity, subtotal, and total as variables
    return render_template('checkout.html', price=cheesecake_price, quantity=quantity, subtotal=subtotal, total=total)






@app.route('/checkout', methods=['POST'])
def process_checkout():
    if 'user_id' in session:
        user_id = session['user_id']

        # Handle form submission
        cheesecake_id = request.form.get('cheesecake_id')
        size = request.form.get('size')
        quantity = request.form.get('quantity')
        cc_name = request.form.get('cc_name')
        cc_number = request.form.get('cc_number')
        cc_expiration = request.form.get('cc_expiration')
        cc_cvv = request.form.get('cc_cvv')

        # Debugging print statements
        print(f"user_id: {user_id}")
        print(f"cheesecake_id: {cheesecake_id}")
        print(f"size: {size}")
        print(f"quantity: {quantity}")
        print(f"cc_name: {cc_name}")
        print(f"cc_number: {cc_number}")
        print(f"cc_expiration: {cc_expiration}")
        print(f"cc_cvv: {cc_cvv}")

        # Calculate the total price
        cheesecake_price = Cheesecake.get_cheesecake_price(cheesecake_id)
        total = float(cheesecake_price) * int(quantity)

        # Debugging print statement
        print(f"Total: {total}")

        # Create an order in the database
        Order.order_id = Order.create_order(user_id, cheesecake_id, quantity, total)

        # Debugging print statement
        print(f"Order ID: {Order.order_id}")

        # Redirect to a confirmation page or perform any other desired actions
        return redirect(url_for('confirmation'))  # Replace 'confirmation' with the actual route name
    else:
        # Handle the case where the user is not logged in
        return redirect(url_for('login_page'))

# Rest of your code...








# @app.route('/checkout', methods=['GET'])
# def display_checkout():
#     quantity_range = range(0, 11)
#     item = "Cheesecake"
#     cheesecakes = Cheesecake.get_all_cheesecakes()

#     # Get the selected cheesecake's price (you need to implement this)
#     selected_cheesecake_id = request.args.get('cheesecake_id')
#     print(f"Selected Cheesecake ID: {selected_cheesecake_id}")  # Debugging print statement

#     cheesecake_price = Order.get_cheesecake_price(selected_cheesecake_id)
#     print(f"Cheesecake Price: {cheesecake_price}")  # Debugging print statement

#     # Get the selected quantity from the URL query string
#     quantity = request.args.get('quantity', '0')  # Use '0' as the default value if 'quantity' is not in the request
#     quantity = int(quantity)  # Convert the value to an integer


#     # Calculate the subtotal and total
#     subtotal, total = Order.calculate_subtotal_and_total(cheesecake_price, quantity)
#     print(f"Subtotal: {subtotal}, Total: {total}")  # Debugging print statement

#     return render_template('checkout.html', item=item, total=total, quantity=quantity, quantity_range=quantity_range, cheesecakes=cheesecakes)









@app.route('/create_order', methods=['POST'])
def create_order():
    # TODO: Check if the user is logged in
    if 'user_id' not in session:
        flash('You must be logged in to create an order.', 'error')
        return redirect('/sign_in')

    # Get order data from the form
    cheesecake_id = request.form.get('cheesecake_id')
    cheesecake_size = request.form.get('size')
    print("cheesecake_id:", cheesecake_id)
    print("cheesecake_size:", cheesecake_size)
    # Get the selected quantity from the URL query string
    quantity = request.args.get('quantity')
    if quantity is not None:
        quantity = int(quantity)
    else:
        flash('Quantity is required.', 'error')
        return redirect('/order')

    # Retrieve the cheesecake by ID
    cheesecake = Cheesecake.get_cheesecake_by_id(cheesecake_id)
    if cheesecake is None:
        flash('Invalid cheesecake selection.', 'error')
        return redirect('/order')

    # Calculate the total cost of the order using the selected size
    try:
        cheesecake_price = Cheesecake.get_cheesecake_price(cheesecake_id)
        total = cheesecake_price * quantity
    except ValueError as e:
        flash(str(e), 'error')
        return redirect('/order')

    # Create a new order with the quantity and total
    order_data = {
        'user_id': session['user_id'],
        'cheesecake_id': cheesecake_id,
        'quantity': quantity,
        'total': total
    }
    order_id = Order.create_order_in_database(order_data)

    flash(f'Order #{order_id} has been created successfully!', 'success')
    return redirect('/dashboard')








@app.route('/thankyou')
def thankyou():
    quantity = range(0, 11)
    item = "Cheesecake"
    total = 25.00
    quantity = 2
    return render_template('thankyou.html', item=item, total=total, quantity=quantity)



