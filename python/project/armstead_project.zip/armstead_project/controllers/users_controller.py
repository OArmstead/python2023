from flask import Flask, request, render_template, redirect, session,flash, get_flashed_messages, jsonify
from charles_arnolds import app
from charles_arnolds.models.user_model import User
from charles_arnolds.models.review_model import Review

from charles_arnolds.controllers.cheesecake_controller import Cheesecake
from flask_bcrypt import Bcrypt
import pprint
bcrypt = Bcrypt(app)
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')








@app.route('/')
def index2():
    return render_template('index2.html')

@app.route('/register')
def register1():
    return render_template('/register.html')

@app.route('/register', methods=['POST'])
def register():
    # Retrieve form data from request
    registration_data = request.form

    # Validate registration data
    if not validate_registration(registration_data):
        # If validation fails, redirect back to registration form with flash messages
        return redirect('/register')

    # If validation passes, hash the password
    hashed_password = bcrypt.generate_password_hash(registration_data['password'])

    # Create a dictionary with user data
    user_data = {
        "first_name": registration_data['first_name'],
        "last_name": registration_data['last_name'],
        "email": registration_data['email'],
        "password": hashed_password  # Use the hashed password
    }

    # Save user data to the database
    user_id = User.save(user_data)

    # Store user_id in the session for user authentication
    session['id'] = user_id

    # Redirect to a welcome or dashboard page
    return redirect('/dashboard')

@app.route('/sign_in')
def sign_in1():
    return render_template('sign_in.html')




@app.route('/sign_in', methods=['POST'])
def sign_in():
    user = User.get_by_email(request.form['email'])

    if not user:
        flash("Invalid Email", "login")
        return redirect('/sign_in')

    if not bcrypt.check_password_hash(user.password, request.form['password']):
        flash("Invalid Password", "login")
        return redirect('/sign_in')

    session['user_id'] = user.id  # Storing the user's ID in the session
    return redirect('/dashboard')



@app.route('/logout')
def logout():
    # Clear the session
    session.clear()
    flash('You have been logged out', 'success')
    return redirect('/')



@app.route('/dashboard')
def dashboard():
    messages = get_flashed_messages()
    # Check if the user is logged in (has 'user_id' in the session)
    if 'user_id' not in session:
        flash('You must log in to access the dashboard.', 'error')
        return redirect('/sign_in')
    all_reviews = Review.get_all_users_reviews()


    seen_comments = set()
    unique_reviews = []
    for review in all_reviews:
        comment = review['comment']
        if comment not in seen_comments:
            unique_reviews.append(review)
            seen_comments.add(comment)
        else:
            # Print duplicate review comments for debugging
            print(f'Duplicate Review Comment: {comment}')

    column1_reviews = unique_reviews[::2]
    column2_reviews = unique_reviews[1::2]
    
    # Pass the separated lists to the template
    return render_template('dash.html', column1_reviews=column1_reviews, column2_reviews=column2_reviews, messages=messages)
    # return render_template('dash.html', reviews=unique_reviews, messages=messages)
    # return render_template('dash.html', reviews=all_reviews, messages=messages)


# Utility function to validate registration data
def validate_registration(registration):
    is_valid = True

    if not EMAIL_REGEX.match(registration['email']):
        flash('Invalid email address!')
        is_valid = False

    if len(registration['first_name']) < 3:
        flash('Your first name must be at least 3 characters.')
        is_valid = False

    if len(registration['last_name']) < 3:
        flash('Your last name must have at least 3 characters')
        is_valid = False

    if len(registration['password']) < 8:
        flash('Password must be at least 8 characters')
        is_valid = False

    if registration['password'] != registration['confirm_password']:
        flash('Your passwords do not match')
        is_valid = False

    return is_valid


@app.route('/get_cheesecake_price_and_quantity', methods=['GET'])
def get_cheesecake_price_and_quantity():
    cheesecake_id = request.args.get('cheesecake_id')
    selected_size = request.args.get('size')

    try:
        # Get the price from the Cheesecake class
        price = Cheesecake.get_cheesecake_price(cheesecake_id)

        # Query the database or another source to get the quantity
        quantity = get_cheesecake_quantity(cheesecake_id, selected_size)

        # Return both price and quantity as a JSON response
        response_data = {
            'price': price,
            'quantity': quantity
        }
        return jsonify(response_data), 200
    except ValueError as e:
        return str(e), 400  # Return an error message with a 400 status code


@app.route('/place_order', methods=['GET'])
def place_order():
    # Retrieve the parameters from the request (assuming they come from the previous page)
    selected_size = request.args.get('size')  # Get the selected_size from the previous page
    cheesecake_id = request.args.get('id')      # Get the cheesecake_id from the previous page

    # Retrieve the subtotal and total from the query parameters
    subtotal = float(request.args.get('subtotal'))
    total = float(request.args.get('total'))

    # You can also fetch other relevant details about the cheesecake here
    cheesecake_name = Cheesecake.get_cheesecake_name(cheesecake_id)
    # Fetch other details as needed

    # Render the place_order.html template and pass the retrieved data
    return render_template('place_order.html', selected_size=selected_size, cheesecake_id=cheesecake_id, cheesecake_name=cheesecake_name, subtotal=subtotal, total=total)
