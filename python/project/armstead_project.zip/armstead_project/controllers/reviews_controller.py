from flask import Flask, request, render_template, redirect, session, flash, get_flashed_messages
from charles_arnolds.config.mysqlconnection import connectToMySQL
from charles_arnolds import app
from charles_arnolds.models.user_model import User
from charles_arnolds.models.review_model import Review
from charles_arnolds.models.cheesecake_model import Cheesecake

# ... (import statements and configurations)






@classmethod
@app.route('/submit_review', methods=['POST'])
def submit_review():
    if request.method == 'POST':
        # Get the values from the form using request.form
        cheesecake_id = request.form['cheesecake_id']
        user_id = request.form['user_id']
        rating = request.form['rating']
        comment = request.form['comment']

        # Check if any of the required fields are missing
        if not cheesecake_id or not user_id or not rating:
            flash("Invalid data format. Please make sure cheesecake_id, user_id, and rating are valid numbers.", "error")
        elif len(comment) < 4:
            flash("Comment must be at least 4 characters long.", "error")
        else:
            Review.save_review(request.form)
            flash("Thank you for your review!", "success")
            return redirect('/dashboard')  # Redirect to the dashboard on success

    return redirect('/rating')  # Redirect back to the form page in case of errors

