from dojos_and_ninjas import app
from dojos_and_ninjas.controllers.controller_index import Ninja
from dojos_and_ninjas.controllers.controller_ninjas import Ninja
from dojos_and_ninjas.controllers.controller_dojo import Dojo

if __name__=='__main__':
    app.run(debug=True)