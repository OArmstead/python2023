from dojos_and_ninjas import app
from flask import render_template,redirect,request
from dojos_and_ninjas.models.ninja import Ninja
from dojos_and_ninjas.models.dojo import Dojo

# @app.route('/')
# def home():
#     return render_template('index.html')

@app.route('/new_ninja')
def new_ninja():
    dojos=Dojo.get_all()
    print(dojos)
    return render_template('new_ninja.html',all_dojos=dojos)


#creating a ninja
@app.route('/create_ninja', methods=['POST'])
def create_ninja():

    # data = {
    #     'first_name': request.form['first_name'],
    #     'last_name':request.form['last_name'],
    #     'age':request.form['age'],
    #     # 'dojo_id': ['dojo_id']
    # }
    Ninja.save(request.form)
    return redirect('/')

#editing a ninja
@app.route('/edit_ninja/<int:ninja_id>')
def edit(ninja_id):
    data={
        'id': ninja_id
    }
    dojos = Dojo.get_all()
    ninja = Ninja.get_one(data)
    return render_template('edit_ninja.html',ninja=ninja,all_dojos =dojos)



@app.route('/edit_ninja/<int:ninja_id>',methods=['POST'])
def edit_ninja(ninja_id):
    data={
        'id': ninja_id,
        'dojo_id': request.form['dojo_id'],
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'age': request.form['age']
    }
    Ninja.edit(data)
    # Dojo.get_one_by_id()
    # dojos = Dojo.get_all_by_id(data)
    # print(request.form['dojo_id'],'$$$$$$$$$$$$$$$$$$$$$$$$$$')
    return redirect("/")


@app.route('/delete_ninja/<int:ninja_id>')
def delete_ninja(ninja_id):
    Ninja.destroy(ninja_id)
    return redirect('/')