from dojos_and_ninjas import app
from flask import render_template,redirect,request
from dojos_and_ninjas.models.dojo import Dojo
# from dojos_and_ninjas.models.ninja import Ninja

@app.route('/new_dojo', methods=['POST'])
def new_dojo():
    Dojo.save(request.form)

    data ={
        'name':request.form['name']
    }
    print(request.form)
    return redirect('/')

@app.route('/show_dojos/<int:dojos_id>')
def show_dojos(dojos_id):
    data ={
        'id': dojos_id
    }
    dojos = Dojo.get_all_by_id(data)
    return render_template('show_dojos.html',dojos = dojos)