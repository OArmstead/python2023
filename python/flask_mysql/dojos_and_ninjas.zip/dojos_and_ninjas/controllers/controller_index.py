from dojos_and_ninjas import app
from flask import render_template,redirect
from dojos_and_ninjas.models.ninja import Ninja
from dojos_and_ninjas.models.dojo import Dojo

@app.route('/')
def home():
    dojos=Dojo.get_all()
    print(dojos)
    return render_template('index.html',all_dojos=dojos)


