from login_and_register import app
from login_and_register.controllers import login_and_registration_controller



if __name__=="__main__":
    app.run(debug=True)