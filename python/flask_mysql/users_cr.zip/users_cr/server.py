from flask import Flask, request, render_template, redirect, session
# from the user.py file import the class
from user import User
app = Flask(__name__)


@app.route('/')
def index():
    users = User.get_all()

    return render_template('show.html', all_users = users)



@app.route('/create_user',methods =['POST'])
def create_user():
# create a dictionary with request.form to get the information from the template. This info needs to be exact as the query string.
    print(request.form)
    print('OK')
    data ={
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email']
    }
    User.save(data)
    return redirect('/')

@app.route('/create_user_page')
def create_user_page():

    return render_template('/create.html')



if __name__=='__main__':
    app.run(debug=True)