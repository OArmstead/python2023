from recipes import app
from recipes.controllers import controller_chefs
from recipes.controllers import controller_index
from recipes.controllers import controller_recipes

if __name__=='__main__':
    app.run(debug=True)