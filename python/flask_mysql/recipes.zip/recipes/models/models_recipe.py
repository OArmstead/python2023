from recipes.config.mysqlconnecton import connectToMySQL
from flask import flash,session
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
from flask_bcrypt import Bcrypt

db ='recipes_schema'



class Recipe:
    def __init__(self,data):
        self.id = data['id']
        self.recipe_name = data['recipe_name']
        self.description = data['description']
        self.instructions = data['instructions']
        self.under_30 = int (data['under_30'])
        self.date_made = data['date_made']
        self.chefs_id = data['chefs_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM recipes_schema.recipes;"
        results = connectToMySQL(db).query_db(query)
        recipes = []
        for recipe in results:
            recipes.append(cls(recipe))
        print(results)
        return recipes

    @classmethod
    def get_one(cls, recipe_id):
        query  = "SELECT * FROM recipes_schema.recipes WHERE id = %(id)s;"
        data = {'id':recipe_id}
        results = connectToMySQL(db).query_db(query, data)
        return cls(results[0])

    @classmethod
    def save_recipe(cls,data):
        query = "INSERT INTO recipes_schema.recipes (recipe_name,description,instructions,under_30,date_made,chefs_id) VALUES(%(recipe_name)s,%(description)s,%(instructions)s,%(under_30)s,%(date_made)s,%(chefs_id)s)"
        return connectToMySQL(db).query_db(query,data)




    @classmethod
    def update(cls, data):
        query = "UPDATE recipes SET recipe_name=%(recipe_name)s, description=%(description)s, instructions=%(instructions)s, under_30=%(under_30)s, date_made=%(date_made)s WHERE id = %(id)s"
        return connectToMySQL(db).query_db(query,data)

    @classmethod
    def delete(cls,data):
        query ='DELETE FROM recipes_schema.recipes WHERE id =%(id)s;'
        return connectToMySQL(db).query_db(query,data)

    @staticmethod
    def validate_recipe(recipe):
        is_valid=True
        if len(recipe['recipe_name']) < 3:
            flash('Enter a recipe name')
            is_valid = False
        if len(recipe['description']) < 3:
            flash('Enter a description')
            is_valid = False
        if len(recipe['instructions']) < 3:
            flash('Enter instructions')
            is_valid = False
        if len(recipe['date_made']) <10:
            flash('enter date format dd/mm/yyyy')
            is_valid = False
        return is_valid


