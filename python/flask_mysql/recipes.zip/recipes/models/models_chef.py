from recipes.config.mysqlconnecton import connectToMySQL
from flask import flash
from .models_recipe import Recipe
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
from flask_bcrypt import Bcrypt


db ='recipes_schema'

class Chef:
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.recipes = []


    @classmethod
    def get_all(cls):
        query = "SELECT * FROM recipes_schema.chefs;"
        results = connectToMySQL(db).query_db(query)
        chefs = []
        for c in results:
            chefs.append(cls(c))
        return chefs

    @classmethod
    def get_one(cls, chef_id):
        query  = "SELECT * FROM recipes_schema.chefs WHERE id = %(id)s;"
        data = {'id':chef_id}
        results = connectToMySQL(db).query_db(query, data)
        return cls(results[0])

    @classmethod
    def chef_with_recipes(cls,data):
        query = 'SELECT * FROM recipes_schema.chefs LEFT JOIN recipes on chefs.id = recipes.chefs_id WHERE chefs.id = %(id)s;'
        results = connectToMySQL(db).query_db(query,data)
        print(results)
        chef = cls(results[0])
        for row in results:
            r ={
                'id': row['recipes.id'],
                'recipe_name': row['recipe_name'],
                'description': row['description'],
                'instructions': row['instructions'],
                'under_30': row['under_30'],
                'date_made': row['date_made'],
                'created_at': row['created_at'],
                'updated_at': row['updated_at']
                }
            chef.recipes.append(Recipe(r))
        return chef



    @classmethod
    def save(cls,data):
        query = "INSERT INTO recipes_schema.chefs (first_name,last_name,email,password) VALUES(%(first_name)s,%(last_name)s,%(email)s,%(password)s)"
        return connectToMySQL(db).query_db(query,data)

    @classmethod
    def get_by_email(cls,data):
        query = 'SELECT * FROM recipes_schema.chefs WHERE email = %(email)s;'
        result = connectToMySQL('registration_schema').query_db(query,data)
        if len(result) < 1:
            return False
        return cls(result[0])

    @classmethod
    def get_by_id(cls,data):
        query ='SELECT * FROM recipes_schema.chefs WHERE id =%(id)s;'
        results = connectToMySQL(db).query_db(query,data)
        return cls(results[0])

    @staticmethod
    def validate_chef(chef):
        is_valid =True
        if not EMAIL_REGEX.match(chef['email']):
            flash('Invalid email address')
            is_valid = False
            is_valid = True

        if len(chef['first_name']) < 3:
            flash('Your first name must be at least 3 characters')
            is_valid = False
        if len(chef['last_name']) < 3:
            flash('Your last name must have at least 3 characters')
            is_valid = False
        if len(chef['email']) <3:
            flash('Enter a valid email')
            is_valid = False
        if len(chef['password']) < 3:
            flash('Password must be at least 3 characters')
            is_valid = False
        if chef['password'] != chef['confirm_password']:
            flash('Your passwords does not match')
        return is_valid