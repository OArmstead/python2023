from recipes import app
from flask import render_template,redirect,session,request
from recipes.models import models_chef
from recipes.models.models_chef import Chef
from recipes.models import models_recipe
from recipes.models.models_recipe import Recipe


@app.route('/new_recipe_page')
def new_recipe_page():
    print(session)

    data ={
        'id':session['id']
    }

    return render_template('new_recipe.html',chef=Chef.get_by_id(data))

@app.route('/new_recipe',methods=['POST'])
def new_recipe():
    print(request.form)
    if not Recipe.validate_recipe(request.form):
        return redirect('/new_recipe_page')
    data = {
        "recipe_name": request.form["recipe_name"],
        "description": request.form["description"],
        "instructions": request.form["instructions"],
        "under_30": int(request.form["under_30"]),
        "date_made": request.form["date_made"],
        "chefs_id": session["chefs_id"]
    }
    Recipe.save_recipe(data)
    return redirect('/welcome')




@app.route('/show_recipe/<int:id>')
def show_recipe(id):
    data ={
        'id': session['id']
    }
    recipe=Recipe.get_one(id)
    chef=Chef.get_by_id(data)
    return render_template('show_recipe.html',one_chef=chef, recipe=recipe)



@app.route('/edit_recipe/<int:id>')
def edit_recipe(id):
    data ={
        'id':session['id']
    }
    recipe=Recipe.get_one(id)
    chef=Chef.get_by_id(data)
    return render_template('edit_recipe.html',one_chef=chef,recipe = recipe)


@app.route('/123/<int:id>',methods=['POST'])
def update_recipe(id):
    print(id)
    if not Recipe.validate_recipe(request.form):
        #Use F string to convert the id pass as <int:id>
        return redirect(f'/edit_recipe/{id}')
    print(request.form)
    print('_______________________________')
    Recipe.get_one(id)
    Recipe.update(request.form)
    return redirect('/welcome')


@app.route('/delete/<int:id>')
def delete(id):
    data={
        'id':id
    }
    Recipe.delete(data)
    return redirect('/welcome')
