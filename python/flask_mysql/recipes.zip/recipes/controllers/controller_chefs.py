from recipes import app
from flask import render_template,redirect,session
from recipes.models import models_chef
from recipes.models.models_chef import Chef
from recipes.models.models_recipe import Recipe



@app.route('/welcome')
def welcome():
    if 'id' not in session:
        return redirect('/logout')
    data ={
        'id': session['id']
    }
    all_chefs = Chef.get_all()
    if 'id' in session:
        print('in session')
    recipes = Recipe.get_all()
    chef=Chef.get_by_id(data)
    return render_template('welcome.html',one_chef = chef, chefs=all_chefs, all_recipes = recipes)


@app.route('/logout')
def logout():
    session.clear
    return redirect('/')



