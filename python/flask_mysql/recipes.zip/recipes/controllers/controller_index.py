from recipes import app
from flask import render_template,session,redirect,request,flash
from recipes.models import models_chef
from recipes.models.models_chef import Chef
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/')
def login():
    return render_template('index.html')


@app.route('/register', methods =['POST'])
def register():

    if not Chef.validate_chef(request.form):
        return redirect('/')
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    # print(pw_hash)
    data = {
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email'],
        'password' :pw_hash
    }
    id = Chef.save(data)
    # Chef.save(request.form)
    session['chefs_id'] = id
    return redirect('/')

@app.route('/chef_login', methods =['POST'])
def chef_login():
    data = {'email': request.form['email']
    }
    registration_in_db = Chef.get_by_email(data)
    if not registration_in_db:
        flash('Invalid Email/Password')
        return redirect('/')
    if not bcrypt.check_password_hash(registration_in_db.password,request.form['password']):
        flash('Invalid Email/Password')
        return redirect('/')
    session['id'] = registration_in_db.id
    session['email'] = request.form['email']
    session['password'] = request.form['password']
    return redirect('/welcome')