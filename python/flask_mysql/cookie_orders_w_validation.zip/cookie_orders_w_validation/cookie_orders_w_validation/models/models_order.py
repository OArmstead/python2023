from cookie_orders_w_validation.config.mysqlconnecton import connectToMySQL
from cookie_orders_w_validation.models import models_order
from flask import flash

# import re
db ='cookie_orders_schema'
class Order:
    def __init__(self,data):
        self.id = data['id']
        self.name = data['name']
        self.cookie_type = data['cookie_type']
        self.number_of_boxes = data['number_of_boxes']
        self.created_at= data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all(cls):
        query = 'SELECT * FROM cookie_orders_schema.orders;'
        results = connectToMySQL(db).query_db(query)
        print(results)
        orders = []
        for order in results:
            orders.append(cls(order))
        return orders

    @classmethod
    def save(cls,data):
        query ='INSERT INTO cookie_orders_schema.orders(name,cookie_type,number_of_boxes) VALUES(%(name)s,%(cookie_type)s,%(number_of_boxes)s);'
        return connectToMySQL(db).query_db(query,data)

    @classmethod
    def get_one(cls,data):
        query = 'SELECT * FROM orders WHERE id = %(id)s'
        results = connectToMySQL(db).query_db(query,data)
        return cls(results[0])

    @classmethod
    def update(cls,data):
        query = 'UPDATE orders SET name = %(name)s,cookie_type = %(cookie_type)s, number_of_boxes = %(number_of_boxes)s WHERE id =%(id)s'
        return connectToMySQL(db).query_db(query,data)

    @staticmethod
    def validate_order(order):
        is_valid = True
        if  len(order['name']) < 2:
            flash('Enter a valid name!')
            is_valid = False
        if  order['cookie_type'] == 'Choose one':
            flash('Enter a cookie type!')
            is_valid = False
        if int(order['number_of_boxes']) < 1:
            flash("C'mon! You made it this far. Order at least one.")
            is_valid = False
        return is_valid

