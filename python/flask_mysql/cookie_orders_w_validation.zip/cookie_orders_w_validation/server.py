from cookie_orders_w_validation import app
from cookie_orders_w_validation.controllers import  controllers_index,controllers_orders

if __name__=='__main__':
    app.run(debug=True)