# from the user.py file import the class
# from flask import Flask, request, render_template, redirect, session
# from user import User

# app.secret_key ='123'
from flask_app import app
from flask_app.controllers import users



if __name__=='__main__':
    app.run(debug=True)