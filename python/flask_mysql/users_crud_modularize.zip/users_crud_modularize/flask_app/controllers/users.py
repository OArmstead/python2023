from flask import request, render_template, redirect, session
from flask_app import app
from flask_app.models.user import User



@app.route('/')
def index():
    users = User.get_all()
    # all_users is variable for HTML
    #users is variable to call the get_all() method
    return render_template('show.html', all_users = users)


@app.route('/create_user_page')
def create_user_page():

    return render_template('/create.html')

@app.route('/create_user',methods =['POST'])
def create_user():
# create a dictionary with request.form to get the information from the template. This info needs to be exact as the query string.
    print(request.form)
    print('OK')
    data ={
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email']
    }
    User.save(data)
    return redirect('/')


#Use the get_one method to get one user from the database
@app.route('/get_one_user/<int:user_id>')
def show_user(user_id):
    data ={
        'id': user_id
    }
    user = User.get_one(data)
    return render_template('/get_one.html', user = user)

@app.route('/update_user/<int:user_id>')
#calling update method for the User class from user.py
def update_user(user_id):
    data = {
        'id': user_id
    }
    user = User.get_one(data)
    return render_template('/edit.html',user = user)

@app.route('/update/<int:user_id>', methods =['POST'])
def update(user_id):
    data = {
        'id': user_id,
        'first_name' :request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email']
    }
    User.update(data)
    return redirect('/')


@app.route('/delete/<int:user_id>')
def delete(user_id):

    User.delete(user_id)
    return redirect('/')