
from flask_app import app
from flask_app.controllers.users import User
from flask import request, redirect, session, render_template 
from users import User
from crypt import methods


@app.route("/")
def index():
    AllUser = User.get_all()
    # print(AllUser)
    return redirect('/read')

@app.route('/read')
def read():
    AllUser = User.get_all()
    print(AllUser)
    return render_template('read.html', AllUser = User.get_all())
            
@app.route('/create')
def enter_info():
    # User.save(request.form)
    return render_template ('create.html')


@app.route('/new_info',methods=['POST'])
def create():
    print('it went through')
    print(request.form)
    User.save(request.form)
    return redirect('/read')

@app.route('/edit_info<int:id>',methods=['POST'])
def edit_info(id):
    User.update(request.form,id)
    return redirect('/edit')

@app.route('/edit<int:id>')
def edit(id):
    user=User.get_one(id)
    User.update
    return render_template('/edit.html',user=user)

@app.route('/show_user<int:id>')
def show(id):
    user=User.get_one(id)
    return render_template('show_user.html',user=user)

@app.route('/delete/<int:id>')
def delete(id):
    User.delete(id)
    return redirect('/')




    
if __name__ == "__main__":
    app.run(debug=True)



# @app.route('/show/int:<id>')
# def show(id):
#     user= User.get_one(id)
#     return render_template('show.html',user = user)








